# pep-energy-project
 A modern, scalable, and serverless data pipeline built on AWS
